"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createYahooFinanceMcpWebHandler = createYahooFinanceMcpWebHandler;
exports.createYahooFinanceMcpNodeHandler = createYahooFinanceMcpNodeHandler;
require("../../_dnt.polyfills.js");
const streamableHttp_js_1 = require("@modelcontextprotocol/sdk/server/streamableHttp.js");
const webStandardStreamableHttp_js_1 = require("@modelcontextprotocol/sdk/server/webStandardStreamableHttp.js");
const server_js_1 = require("./server.js");
const DEFAULT_ALLOWED_HOSTS = ["127.0.0.1", "localhost", "::1"];
function jsonRpcError(status, code, message) {
    return {
        status,
        body: {
            jsonrpc: "2.0",
            error: { code, message },
            id: null,
        },
    };
}
function writeJsonResponse(res, status, body) {
    res.writeHead(status, { "content-type": "application/json" });
    res.end(JSON.stringify(body));
}
function getHostName(hostHeader) {
    const host = hostHeader?.split(",")[0]?.trim();
    if (!host)
        return undefined;
    if (host.startsWith("[")) {
        const end = host.indexOf("]");
        return end === -1 ? host : host.slice(1, end);
    }
    const colonCount = host.split(":").length - 1;
    if (colonCount === 1)
        return host.split(":")[0];
    return host;
}
function validateHost(hostHeader, allowedHosts) {
    if (allowedHosts.length === 0)
        return undefined;
    const hostname = getHostName(hostHeader);
    if (hostname && allowedHosts.includes(hostname))
        return undefined;
    return jsonRpcError(403, -32000, `Invalid Host header: ${hostHeader ?? "(missing)"}`);
}
function validateOrigin(origin, allowedOrigins) {
    if (!origin || allowedOrigins.length === 0)
        return undefined;
    if (allowedOrigins.includes(origin))
        return undefined;
    return jsonRpcError(403, -32000, `Invalid Origin header: ${origin}`);
}
function validateBearerToken(authorization, bearerToken) {
    if (!bearerToken)
        return undefined;
    if (authorization === `Bearer ${bearerToken}`)
        return undefined;
    return jsonRpcError(401, -32001, "Missing or invalid bearer token.");
}
function validateRequestHeaders(headers, options) {
    const allowedHosts = options.allowedHosts ?? DEFAULT_ALLOWED_HOSTS;
    return validateHost(headers.get("host"), allowedHosts) ??
        validateOrigin(headers.get("origin"), options.allowedOrigins ?? []) ??
        validateBearerToken(headers.get("authorization"), options.bearerToken);
}
function validateNodeRequestHeaders(req, options) {
    const allowedHosts = options.allowedHosts ?? DEFAULT_ALLOWED_HOSTS;
    const header = (name) => {
        const value = req.headers[name.toLowerCase()];
        return Array.isArray(value) ? value[0] : value;
    };
    return validateHost(header("host"), allowedHosts) ??
        validateOrigin(header("origin"), options.allowedOrigins ?? []) ??
        validateBearerToken(header("authorization"), options.bearerToken);
}
async function closeServer(server) {
    try {
        await server.close();
    }
    catch {
        // Nothing useful to report after a request is already complete.
    }
}
function createYahooFinanceMcpWebHandler(options) {
    const path = options.path ?? "/mcp";
    return async function handleYahooFinanceMcpRequest(request) {
        const url = new URL(request.url);
        if (url.pathname !== path) {
            return new Response("Not Found", { status: 404 });
        }
        const validationError = validateRequestHeaders(request.headers, options);
        if (validationError) {
            return Response.json(validationError.body, {
                status: validationError.status,
            });
        }
        const server = (0, server_js_1.createYahooFinanceMcpServer)(options);
        const transport = new webStandardStreamableHttp_js_1.WebStandardStreamableHTTPServerTransport({
            sessionIdGenerator: undefined,
            enableJsonResponse: true,
        });
        try {
            await server.connect(transport);
            return await transport.handleRequest(request);
        }
        catch (error) {
            const message = error instanceof Error ? error.message : String(error);
            const response = jsonRpcError(500, -32603, message);
            return Response.json(response.body, { status: response.status });
        }
        finally {
            await transport.close();
            await closeServer(server);
        }
    };
}
function createYahooFinanceMcpNodeHandler(options) {
    const path = options.path ?? "/mcp";
    return async function handleYahooFinanceMcpNodeRequest(req, res) {
        const host = Array.isArray(req.headers.host)
            ? req.headers.host[0]
            : req.headers.host ?? "127.0.0.1";
        const url = new URL(req.url ?? "/", `http://${host}`);
        if (url.pathname !== path) {
            res.writeHead(404, { "content-type": "text/plain" });
            res.end("Not Found");
            return;
        }
        const validationError = validateNodeRequestHeaders(req, options);
        if (validationError) {
            writeJsonResponse(res, validationError.status, validationError.body);
            return;
        }
        const server = (0, server_js_1.createYahooFinanceMcpServer)(options);
        const transport = new streamableHttp_js_1.StreamableHTTPServerTransport({
            sessionIdGenerator: undefined,
            enableJsonResponse: true,
        });
        try {
            await server.connect(transport);
            await transport.handleRequest(req, res);
        }
        catch (error) {
            if (!res.headersSent) {
                const message = error instanceof Error ? error.message : String(error);
                const response = jsonRpcError(500, -32603, message);
                writeJsonResponse(res, response.status, response.body);
            }
            else {
                res.end();
            }
        }
        finally {
            await transport.close();
            await closeServer(server);
        }
    };
}
