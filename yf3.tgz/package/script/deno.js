"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    "name": "@gadicc/yahoo-finance2",
    "version": "3.15.3",
    "tasks": {
        "cli": "deno run -A bin/yahoo-finance.ts",
        "docs:gen": "deno doc --output=jsdocs --html $(jq -r '.exports | to_entries[] | .value' deno.json)",
        "docs:lint": "deno doc --output=jsdocs --lint --html $(jq -r '.exports | to_entries[] | .value' deno.json)",
        "docs:open": "xdg-open file://$(pwd)/jsdocs/index.html",
        "docs:watch": "deno eval 'const run=async()=>{const p=new Deno.Command(\"deno\",{args:[\"task\",\"docs:gen\"],stdout:\"inherit\",stderr:\"inherit\"}).spawn(); const {code}=await p.status; if(code) console.error(\"[docs:gen] exited\", code);}; let t; const kick=()=>{clearTimeout(t); t=setTimeout(run,120)}; await run(); for await(const _ of Deno.watchFs([\"src\",\"docs\",\"scripts\",\"README.md\"])) kick();'",
        "install-cli": "deno install -A --global -n yahoo-finance npm:yahoo-finance/bin/yahoo-finance.ts",
        "schema_": "TODO below... separate watch mode, vscode scripts, mtime check, etc",
        "schema": "deno run -A scripts/schema-gen.ts",
        "test": "deno test --no-prompt -P=test --parallel --ignore=tests/cloudflare",
        "test:serial": "deno test --no-prompt -P=test --ignore=tests/cloudflare",
        "test:cloudflare": "deno task build:npm && npm ci --prefix tests/cloudflare && npm test --prefix tests/cloudflare",
        "lock:cloudflare": "npx -p npm@10.9.4 npm install --prefix tests/cloudflare --package-lock-only",
        "build:npm": "deno run -A scripts/build_npm.ts",
        "devTODO": "deno run --watch main.ts"
    },
    "permissions": {
        "test": {
            "read": ["./tests/fixtures/http", "./tests/http"],
            "write": ["./tests/fixtures/http"],
            "env": {
                "allow": [
                    "FETCH_DEVEL",
                    "FETCH_DEVEL_RECACHE_CONCURRENCY",
                    "FETCH_DEVEL_RECACHE_INTERVAL"
                ],
                "ignore": true
            },
            "net": [
                "query1.finance.yahoo.com",
                "query2.finance.yahoo.com",
                "finance.yahoo.com",
                "guce.yahoo.com",
                "consent.yahoo.com"
            ]
        }
    },
    "test": {
        "permissions": "test"
    },
    "exports": {
        "./src/index.ts": "./src/index.ts",
        ".": "./src/index.ts",
        "./createYahooFinance": "./src/createYahooFinance.ts",
        "./mcp": "./src/mcp/mod.ts",
        "./mcp/http": "./src/mcp/http.ts",
        "./mcp/server": "./src/mcp/server.ts",
        "./modules": "./src/modules/index.ts",
        "./modules/autoc": "./src/modules/autoc.ts",
        "./modules/chart": "./src/modules/chart.ts",
        "./modules/dailyGainers": "./src/modules/dailyGainers.ts",
        "./modules/dailyLosers": "./src/modules/dailyLosers.ts",
        "./modules/fundamentalsTimeSeries": "./src/modules/fundamentalsTimeSeries.ts",
        "./modules/historical": "./src/modules/historical.ts",
        "./modules/insights": "./src/modules/insights.ts",
        "./modules/options": "./src/modules/options.ts",
        "./modules/quoteSummary-iface": "./src/modules/quoteSummary-iface.ts",
        "./modules/quoteSummary": "./src/modules/quoteSummary.ts",
        "./modules/quote": "./src/modules/quote.ts",
        "./modules/recommendationsBySymbol": "./src/modules/recommendationsBySymbol.ts",
        "./modules/screener": "./src/modules/screener.ts",
        "./modules/search": "./src/modules/search.ts",
        "./modules/trendingSymbols": "./src/modules/trendingSymbols.ts",
        "./other": "./src/other/index.ts",
        "./other/quoteCombine": "./src/other/quoteCombine.ts",
        "./lib/moduleCommon": "./src/lib/moduleCommon.ts",
        "./lib/cookieJar": "./src/lib/cookieJar.ts",
        "./lib/getCrumb": "./src/lib/getCrumb.ts",
        "./lib/options": "./src/lib/options/options.ts"
    },
    "imports": {
        "@deno/dnt": "jsr:@deno/dnt@^0.42.3",
        "@gadicc/fetch-mock-cache": "jsr:@gadicc/fetch-mock-cache@^2.2.0",
        "@modelcontextprotocol/sdk/client/index.js": "npm:@modelcontextprotocol/sdk@^1.26.0/client/index.js",
        "@modelcontextprotocol/sdk/inMemory.js": "npm:@modelcontextprotocol/sdk@^1.26.0/inMemory.js",
        "@modelcontextprotocol/sdk/server/mcp.js": "npm:@modelcontextprotocol/sdk@^1.26.0/server/mcp.js",
        "@modelcontextprotocol/sdk/server/stdio.js": "npm:@modelcontextprotocol/sdk@^1.26.0/server/stdio.js",
        "@modelcontextprotocol/sdk/server/streamableHttp.js": "npm:@modelcontextprotocol/sdk@^1.26.0/server/streamableHttp.js",
        "@modelcontextprotocol/sdk/server/webStandardStreamableHttp.js": "npm:@modelcontextprotocol/sdk@^1.26.0/server/webStandardStreamableHttp.js",
        "@modelcontextprotocol/sdk/types.js": "npm:@modelcontextprotocol/sdk@^1.26.0/types.js",
        "@sebbo2002/semantic-release-jsr": "npm:@sebbo2002/semantic-release-jsr@^4.0.0",
        "@semantic-release/exec": "npm:@semantic-release/exec@^7.1.0",
        "@jest/types": "npm:@jest/types@^29.6.3",
        "@std/async": "jsr:@std/async@^1.0.11",
        "@std/cli": "jsr:@std/cli@^1.0.14",
        "@std/expect": "jsr:@std/expect@^1.0.13",
        "@std/fmt": "jsr:@std/fmt@^1.0.5",
        "@std/fs": "jsr:@std/fs@^1.0.13",
        "@std/path": "jsr:@std/path@^1.1.2",
        "@std/testing": "jsr:@std/testing@^1.0.9",
        "@types/json-schema": "npm:@types/json-schema@^7.0.15",
        "conventional-changelog-conventionalcommits": "npm:conventional-changelog-conventionalcommits@^8.0.0",
        "fetch-mock-cache": "npm:fetch-mock-cache@^2.1.3",
        "jest-get-type": "npm:jest-get-type@^29.6.3",
        "json-schema": "npm:json-schema@^0.4.0",
        "oas-schema-walker": "npm:oas-schema-walker@^1.1.5",
        "semantic-release": "npm:semantic-release@^25.0.2",
        "tough-cookie": "npm:tough-cookie@^5.1.1",
        "tough-cookie-file-store": "npm:tough-cookie-file-store@^2.0.3",
        "ts-json-schema-generator": "npm:ts-json-schema-generator@^2.4.0",
        "zod/v4": "npm:zod@^3.25.0/v4"
    },
    "nodeModulesDir": "auto",
    "fmt": {
        "exclude": ["tests/fixtures", "tests/http", "**/*.schema.json"]
    },
    "publish": {
        "exclude": [
            "./.circleci",
            "./.editorconfig",
            "./.github",
            "./.vscode",
            "./docs",
            "./scripts",
            "./tests"
        ]
    },
    "compilerOptions": {
        "lib": [
            "dom",
            "dom.iterable",
            "dom.asynciterable",
            "deno.ns"
        ]
    }
};
