import "../../_dnt.polyfills.js";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
export type YahooFinanceMcpClient = Record<string, (...args: unknown[]) => unknown>;
export interface CreateYahooFinanceMcpServerOptions {
    /** Existing yahoo-finance2 client instance to expose over MCP. */
    client: YahooFinanceMcpClient;
    /** MCP server name shown to clients. */
    name?: string;
    /** MCP server version shown to clients. */
    version?: string;
    /** Optional allow-list of tool names to expose. */
    enabledTools?: string[];
}
export declare function getYahooFinanceMcpToolNames(): string[];
export declare function createYahooFinanceMcpServer(options: CreateYahooFinanceMcpServerOptions): McpServer;
//# sourceMappingURL=server.d.ts.map