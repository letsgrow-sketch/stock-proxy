import "../../_dnt.polyfills.js";
import type { IncomingMessage, ServerResponse } from "node:http";
import { type CreateYahooFinanceMcpServerOptions } from "./server.js";
export interface YahooFinanceMcpHttpOptions extends CreateYahooFinanceMcpServerOptions {
    /** HTTP path that handles MCP requests. Defaults to /mcp. */
    path?: string;
    /** Allowed Host header hostnames. Defaults to localhost hostnames. Empty array disables host checks. */
    allowedHosts?: string[];
    /** Allowed Origin header values. Empty or omitted means Origin is not checked. */
    allowedOrigins?: string[];
    /** Optional bearer token required for every HTTP MCP request. */
    bearerToken?: string;
}
export type YahooFinanceMcpWebHandler = (request: Request) => Promise<Response>;
export type YahooFinanceMcpNodeHandler = (req: IncomingMessage, res: ServerResponse) => Promise<void>;
export declare function createYahooFinanceMcpWebHandler(options: YahooFinanceMcpHttpOptions): YahooFinanceMcpWebHandler;
export declare function createYahooFinanceMcpNodeHandler(options: YahooFinanceMcpHttpOptions): YahooFinanceMcpNodeHandler;
//# sourceMappingURL=http.d.ts.map