export declare const EXIT_OK = 0;
export declare const EXIT_RUNTIME_ERROR = 1;
export declare const EXIT_USAGE = 2;
type Print = (...args: unknown[]) => void;
type DirPrint = (value: unknown, options?: {
    depth?: number | null;
    colors?: boolean;
}) => void;
export interface CliOutput {
    stdout: Print;
    stderr: Print;
    stdoutDir: DirPrint;
    stderrDir: DirPrint;
}
export interface CliLogger {
    info: Print;
    warn: Print;
    error: Print;
    debug: Print;
    dir: DirPrint;
}
export type CliClient = Record<string, (...args: unknown[]) => unknown>;
export interface RunCliOptions {
    args: string[];
    version: string;
    moduleNames: string[];
    createClient: (logger: CliLogger) => CliClient;
    output?: CliOutput;
    readStdin?: () => string | Promise<string>;
    stdoutIsTerminal?: () => boolean;
}
export declare function getModuleNames(prototype: object): string[];
export declare function createCliLogger(output: CliOutput): CliLogger;
export declare function runCli(options: RunCliOptions): Promise<1 | 2 | 0>;
export {};
//# sourceMappingURL=cli.d.ts.map