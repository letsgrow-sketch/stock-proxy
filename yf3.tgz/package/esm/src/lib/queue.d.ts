interface Job {
    func: () => Promise<unknown>;
    resolve: (arg: any) => void;
    reject: (arg: any) => void;
}
export interface QueueOptions {
    /** Max number of simultaneous network requests */
    concurrency?: number;
    /** Minimum delay between starting queued requests, in milliseconds */
    interval?: number;
}
export default class Queue {
    concurrency: number;
    interval: number;
    _running: number;
    _queue: Array<Job>;
    _lastRun: number;
    _timer: ReturnType<typeof setTimeout> | null;
    constructor(opts?: QueueOptions);
    runNext(): void;
    checkQueue(): void;
    add(func: () => Promise<unknown>): Promise<unknown>;
}
export {};
//# sourceMappingURL=queue.d.ts.map