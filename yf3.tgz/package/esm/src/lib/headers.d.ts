export declare function getSetCookieHeaders(headers: Headers): string[];
//# sourceMappingURL=headers.d.ts.map