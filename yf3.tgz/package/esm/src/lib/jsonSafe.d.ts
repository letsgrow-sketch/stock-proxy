export declare function toJsonSafe(value: unknown, stack?: WeakSet<object>): unknown;
export declare function stringifyJsonSafe(value: unknown, space?: number): string;
//# sourceMappingURL=jsonSafe.d.ts.map