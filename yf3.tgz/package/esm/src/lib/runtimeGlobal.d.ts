export declare function getRuntimeGlobal(): Record<string, unknown>;
export declare function getGlobalValue(name: string): unknown;
//# sourceMappingURL=runtimeGlobal.d.ts.map