declare namespace _default {
    export let name: string;
    export let version: string;
    export let tasks: {
        cli: string;
        "docs:gen": string;
        "docs:lint": string;
        "docs:open": string;
        "docs:watch": string;
        "install-cli": string;
        schema_: string;
        schema: string;
        test: string;
        "test:serial": string;
        "test:cloudflare": string;
        "lock:cloudflare": string;
        "build:npm": string;
        devTODO: string;
    };
    export namespace permissions {
        namespace test {
            let read: string[];
            let write: string[];
            namespace env {
                let allow: string[];
                let ignore: boolean;
            }
            let net: string[];
        }
    }
    export namespace test_1 {
        let permissions_1: string;
        export { permissions_1 as permissions };
    }
    export { test_1 as test };
    export let exports: {
        "./src/index.ts": string;
        ".": string;
        "./createYahooFinance": string;
        "./mcp": string;
        "./mcp/http": string;
        "./mcp/server": string;
        "./modules": string;
        "./modules/autoc": string;
        "./modules/chart": string;
        "./modules/dailyGainers": string;
        "./modules/dailyLosers": string;
        "./modules/fundamentalsTimeSeries": string;
        "./modules/historical": string;
        "./modules/insights": string;
        "./modules/options": string;
        "./modules/quoteSummary-iface": string;
        "./modules/quoteSummary": string;
        "./modules/quote": string;
        "./modules/recommendationsBySymbol": string;
        "./modules/screener": string;
        "./modules/search": string;
        "./modules/trendingSymbols": string;
        "./other": string;
        "./other/quoteCombine": string;
        "./lib/moduleCommon": string;
        "./lib/cookieJar": string;
        "./lib/getCrumb": string;
        "./lib/options": string;
    };
    export let imports: {
        "@deno/dnt": string;
        "@gadicc/fetch-mock-cache": string;
        "@modelcontextprotocol/sdk/client/index.js": string;
        "@modelcontextprotocol/sdk/inMemory.js": string;
        "@modelcontextprotocol/sdk/server/mcp.js": string;
        "@modelcontextprotocol/sdk/server/stdio.js": string;
        "@modelcontextprotocol/sdk/server/streamableHttp.js": string;
        "@modelcontextprotocol/sdk/server/webStandardStreamableHttp.js": string;
        "@modelcontextprotocol/sdk/types.js": string;
        "@sebbo2002/semantic-release-jsr": string;
        "@semantic-release/exec": string;
        "@jest/types": string;
        "@std/async": string;
        "@std/cli": string;
        "@std/expect": string;
        "@std/fmt": string;
        "@std/fs": string;
        "@std/path": string;
        "@std/testing": string;
        "@types/json-schema": string;
        "conventional-changelog-conventionalcommits": string;
        "fetch-mock-cache": string;
        "jest-get-type": string;
        "json-schema": string;
        "oas-schema-walker": string;
        "semantic-release": string;
        "tough-cookie": string;
        "tough-cookie-file-store": string;
        "ts-json-schema-generator": string;
        "zod/v4": string;
    };
    export let nodeModulesDir: string;
    export namespace fmt {
        let exclude: string[];
    }
    export namespace publish {
        let exclude_1: string[];
        export { exclude_1 as exclude };
    }
    export namespace compilerOptions {
        let lib: string[];
    }
}
export default _default;
//# sourceMappingURL=deno.d.ts.map